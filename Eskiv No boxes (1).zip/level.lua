local width = 750fx
local height = 750fx
pewpew.set_level_size(width, height)
local ground = pewpew.new_customizable_entity(width / 750fx, height / 750fx)
pewpew.customizable_entity_set_mesh(ground, "/dynamic/background.lua", 0)
local function random_position()
  return fmath.random_fixedpoint(0fx, width), fmath.random_fixedpoint(0fx, height)
end
local bg = pewpew.new_customizable_entity(0fx, 0fx)
pewpew.customizable_entity_set_mesh(bg, "/dynamic/level_graphics.lua", 0)
pewpew.configure_player(0, {shield = 3, camera_distance = -400fx, camera_rotation_x_axis = fmath.tau() / -55fx})
pewpew.configure_player(0, {shoot_joystick_color = 0})
local ship = pewpew.new_player_ship(width / 2fx, height / 2fx, 0)
function clamp(v, min, max)
  return v
end
local counter = pewpew.new_customizable_entity(width / 8fx, height / -12fx)
pewpew.customizable_entity_set_mesh_scale(counter,3fx)
local time = 0
local count = 10
pewpew.add_update_callback(function()
  time = time + 1
  local conf = pewpew.get_player_configuration(0)
  if conf["has_lost"] == true then
    pewpew.stop_game()
  end
  if time % 30 == 0 then
    count = count - 1
  end
  if time % 25 == 0 then
    local x, y = random_position()
    pewpew.new_rolling_sphere(x, y, fmath.random_fixedpoint(0fx,fmath.tau()), 1fx)
  end
  if pewpew.entity_get_is_alive(counter) then
    if count >= 0 then
      pewpew.customizable_entity_set_string(counter, "#aa55ddff" .. count)
    end
    if count == -1 then
       if sc>=S1req then
            S1req=-1E9
            local s=conf.shield
            pewpew.configure_player(0,{shield=s+1})
            pewpew.increase_score_of_player(0,100*s)
            local timeBonus = math.max(2700-t,0)
            pewpew.increase_score_of_player(0,timeBonus)
            main()
            pewpew.new_floating_message(50fx,-12fx,"#ffffffff+"..100*s,{dz=8fx,ticks_before_fade=45})
        end
      pewpew.entity_destroy(counter)
      pewpew.stop_game()
    end
  end
end)